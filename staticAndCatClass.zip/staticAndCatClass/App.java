// aD 9/18/2025

public class App {
    public static void main(String[] args) {
        System.out.println(Cat.getCatCount());
        Cat myCat = new Cat();
        myCat.meow();
        myCat.name = "Arthur";
        myCat.age = 8;
        System.out.println(Cat.MAX_LIVES);
        System.out.println(Cat.getCatCount());
    }
}
