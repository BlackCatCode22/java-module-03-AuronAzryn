package mystuff;

public class MyStuff {
    // Attributes (characteristics of the game)
    private final String title;
    private final String genre;
    private int playerCount;
    private int missionsCompleted;

    // Constructor (how we create a Helldivers 2 object)
    public MyStuff(String title, String genre, int playerCount) {
        this.title = title;
        this.genre = genre;
        this.playerCount = playerCount;
        this.missionsCompleted = 0; // start at 0 missions
    }

    // Methods (behaviors of the game)
    public void playMission() {
        missionsCompleted++;
        System.out.println("Mission completed! Total missions: " + missionsCompleted);
    }

    public void recruitPlayers(int newPlayers) {
        playerCount += newPlayers;
        System.out.println(newPlayers + " players joined. Total now: " + playerCount);
    }

    public void info() {
        System.out.println(title + " (" + genre + ") - "
                + playerCount + " players online. Missions completed: " + missionsCompleted);
    }
}

