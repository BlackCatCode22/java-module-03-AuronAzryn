package mystuff;

public class Driver {
    public static void main(String[] args) {
        // Create a Helldivers 2 object
        MyStuff helldivers = new MyStuff("Helldivers 2", "Co-op Shooter", 50000);

        // Use its methods
        helldivers.info();             // Show starting game info
        helldivers.playMission();      // Complete a mission
        helldivers.playMission();      // Complete another mission
        helldivers.recruitPlayers(500); // Recruit more players
        helldivers.info();             // Show updated game info
    }
}
