package myanimals;

public class Driver {
    public static void main(String[] args) {
        Cat cat1 = new Cat("Phebe");
        Dog dog1 = new Dog("Crypto");
        Cat cat2 = new Cat("Puss in Boots");

        cat1.speak();
        dog1.speak();
        cat2.speak();
    }
}
