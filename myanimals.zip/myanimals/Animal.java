package myanimals;

public class Animal {
    // static variable shared across all Animal objects
    protected static int numOfAnimals = 0;

    // Attributes
    protected String name;

    // Constructor
    public Animal(String name) {
        this.name = name;
        numOfAnimals++; // increase count whenever an animal is created
        System.out.println("Created a new animal: " + name);
        System.out.println("Current number of animals: " + numOfAnimals);
    }

    // Method
    public void speak() {
        System.out.println(name + " makes a sound.");
    }
}
