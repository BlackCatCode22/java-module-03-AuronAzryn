package myanimals;

public class Dog extends Animal {
    public Dog(String name) {
        super(name); // call the Animal constructor
    }

    @Override
    public void speak() {
        System.out.println(name + " says: Woof!");
    }
}
