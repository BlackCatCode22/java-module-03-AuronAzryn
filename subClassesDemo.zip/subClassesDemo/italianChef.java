public class italianChef {

    public void makePasta() {
        System.out.println("The chef makes pasta.");
    }
}
