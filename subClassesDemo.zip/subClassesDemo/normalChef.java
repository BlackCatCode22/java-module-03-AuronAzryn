public class normalChef {

    public void makeSpecialDish() {
        System.out.println("The chef makes pulled pork.");
    }

}
