// App.java
// aD 9/16/25

public class App {
    public static void main(String[] args) {

        System.out.println("\n Welcome to Subclasses! \n");

        // Create a chef obj
        normalChef myChef = new normalChef();
        myChef.makeSpecialDish();

        // create a italian chef obj
        italianChef ItalianChef = new italianChef();
        ItalianChef.makePasta();

        // create a chinese chef obj
        chineseChef chineseChef = new chineseChef();
        chineseChef.makeFriedRice();
        chineseChef.makeSpecialDish();


    }
}
