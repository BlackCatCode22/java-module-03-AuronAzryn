public class chineseChef extends normalChef {

    public void makeSpecialDish() {
        System.out.println("The chef makes orange chicken.");
    }

    public void makeFriedRice() {
        System.out.println("The chef makes fried rice.");
    }
}
