public class Constructor {
    public static void main(String[] args) {

        Dog myDog = new Dog("Jerry", 9);
        System.out.println(myDog.name + " " + myDog.age);




    }
}
